#include <stdio.h>
#include <ctype.h>

#define PI 3.14159265358979323846

int main()
{
	printf("The primary purpose of this program is to calculate both the Area and\nCircumference of a circle\n");
	char upCase;
	double radius;
        float area;
        float circumference;
        char answer[100];

	do{
			
		printf("\nPlease type the radius of the circle(radius > 0).\n");
		scanf("%lf",&radius);
	
		while(radius <= 0){
			printf("Invalid radius! Please retype a valid radius.\n");
			scanf("%lf",&radius);
		}
		
		area = PI * radius * radius;
		circumference = 2 * PI * radius;
	
		printf("\nThe area of the circle is: %.2f", area);
		printf("\nThe circumference of the circle is: %.2f", circumference); 
	
		printf("\nDo you want to enter another radius for a circle? (Y/N)\n");
		scanf("%s", answer); 
		upCase =toupper(answer[0]);

	}while(upCase == 'Y');


}
